package com.example.movieapplication.Activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.movieapplication.R;
import com.squareup.picasso.Picasso;

public class DetailedActivity extends AppCompatActivity {

    TextView overView;
    TextView releaseData;
    TextView nameOfTheMovie;
    ImageView movieImage;
    RatingBar ratingbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailed);

        overView = findViewById(R.id.overview_of_the_movie);
        releaseData = findViewById(R.id.release_date);
        nameOfTheMovie = findViewById(R.id.movie_name);
        movieImage = findViewById(R.id.image_of__the_movie);
        ratingbar = findViewById(R.id.rating);

        Intent intent = getIntent();
        if (intent.hasExtra("nameOfTheMovie")) {
            String title = intent.getStringExtra("nameOfTheMovie");
            nameOfTheMovie.setText(title);
        }
        if (intent.hasExtra("release_date")) {
            String release_date = intent.getStringExtra("release_date");
            releaseData.setText(release_date);
        }
        if (intent.hasExtra("overview")) {
            String overview = intent.getStringExtra("overview");
            overView.setText(overview);
        }
        if (intent.hasExtra("rating")) {
            float rating = Float.valueOf(intent.getStringExtra("rating"));
            ratingbar.setRating(rating / 2);
            // dvRating.setText(rating);
        }
        if (intent.hasExtra("poster_path")) {
            String poster_path = intent.getStringExtra("poster_path");
            Picasso.get().load("http://image.tmdb.org/t/p/w185/" + poster_path).placeholder(R.drawable.download).error(R.drawable.download).into(movieImage);
        }


    }
}
